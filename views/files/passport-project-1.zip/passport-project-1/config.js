module.exports = {
  "secretKey" : '12345-67890-0976-54321',
  "mongoUrl" : "mongodb://localhost:27017/conFusion"
};
