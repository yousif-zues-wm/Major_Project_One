var express = require('express');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var Verify = require('./verify.js');

var Promotions = require('../models/promotions');

var promoRouter = express.Router();
promoRouter.use(bodyParser.json());

promoRouter.route('/')
.get(Verify.verifyOrdinaryUser,function (req, res, next) {
    Promotions.find({}, function (err, promotions) {
        if (err) throw err;
        res.json(promotions);
    });
})

.post(Verify.verifyAdmin,function (req, res, next) {
    Promotions.create(req.body, function (err, promotions) {
        if (err) throw err;
        console.log('Promotion created!');
        var id = promotions._id;

        res.writeHead(200, {
            'Content-Type': 'text/plain'
        });
        res.end('Added the promotion with id: ' + id);
    });
})

.delete(Verify.verifyAdmin,function (req, res, next) {
    Promotions.remove({}, function (err, resp) {
        if (err) throw err;
        res.json(resp);
    });
});

promoRouter.route('/:promotionsId')
.get(Verify.verifyOrdinaryUser,function (req, res, next) {
    Promotions.findById(req.params.promotionsId, function (err, promotions) {
        if (err) throw err;
        res.json(promotions);
    });
})

.put(Verify.verifyAdmin,function (req, res, next) {
    Promotions.findByIdAndUpdate(req.params.promotionsId, {
        $set: req.body
    }, {
        new: true
    }, function (err, promotions) {
        if (err) throw err;
        res.json(promotions);
    });
})

.delete(Verify.verifyAdmin,function (req, res, next) {
    Promotions.findByIdAndRemove(req.params.promotionsId, function (err, resp) {
      if (err) throw err;
        res.json(resp);
    });
});


module.exports = promoRouter;
