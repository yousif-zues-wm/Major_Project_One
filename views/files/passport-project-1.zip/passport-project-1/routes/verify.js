var User = require('../models/user');
var jwt = require('jsonwebtoken');
var config = require('../config.js');
var adminP = false;
var userP = false;

exports.getToken = function(user){
  return jwt.sign(user, config.secretKey, {
    expiresIn: 36000
  });
};

exports.verifyOrdinaryUser = function(req,res,next){
  var token = req.body.token || req.query.token || req.headers['x-access-token'];
  if (token) {
    jwt.verify(token, config.secretKey, function(err, decoded){
      if (err) {
        var err = new Error('Not Signed in!!');
        err.status = 401;
        return next(err);
      }else{
        req.decoded = decoded;
        next();
        userP = true;
      }
    });
  }else{
    var err = new Error('No Token!!');
    err.status = 403;
    return next(err);
  }
};

exports.verifyAdmin = function(req, res, next) {
    var token = req.body.token || req.query.token || req.headers['x-access-token'];
    var decAdmin = jwt.decode(token, { complete: true });
    if (token) {
        jwt.verify(token, config.secretKey, function(err, decoded) {
            if (err || !decAdmin.payload._doc.admin) {
                var err = new Error('You are not authorized to perform this operation!');
                err.status = 403;
                return next(err);
            } else {
                req.decoded = decoded;
                next();
                adminP = true;
            }
        });
    } else {
        var err = new Error('No token provided!!!!');
        err.status = 403;
        return next(err);
    }
};
